The .json file StoryBook contains a dictionary with arrays full of stories to put in to the game.

I didn't use it because there were two ways to do it: using the .json file to write the stories in the game or using the node system within the godot engine.
I choose the second choice but if you want the first one you can look at the godot docs for putting in .json files in the project. The lines of code i used for testing
the game with the json file were the same. In this case you can create a new function for bringing the StoryBook into the script and then call it in the ready function.

For any doubts you can see this guy tutorial for making Save mechanics on godot using json. It's the same method.

Tutorial:
https://www.youtube.com/watch?v=XQptE6qrhKA&t=1s

If you have more doubts:
https://www.youtube.com/watch?v=8HOmLNuuccs&t=326s

Anyway, do as you will and the way you find better, if you find another way out of these above, i would apreciate if you shared it with me.